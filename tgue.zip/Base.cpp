#include <stdio.h>      /* printf */
#include <time.h>       /* clock_t, clock, CLOCKS_PER_SEC */
#include <math.h>       /* sqrt */
#include <iostream>
#include <array>
#include <string>


using namespace std;
string Name;

int main ()
{
    
    cout<<"Hello World\n";
    return 0;
}
/*  
The main gameloop it calls the functions, classes, variables and database values

/**/

class map
{
    array<array<char, 40>, 20> importMap (string filename)
    {
        ifstream level;
    }
    void drawMap()
    {
        
    }
};

/*
The class to draw and call the map to the game loop
/**/

class movement
{
    void ChangePosition(inital_posx, inital_posy, next_posx, next_posy)
    {
        if next_posx > map_size || next_posy > map_size
        {
            cout << "Your movement is invalid and wrong: next position is larger than the map" << endl;
        }
        
    }
};

/*
The class to check position, change position, check new position
/**/

class player
{
    
};
/*
the class to hold functions relating to player, holds some data relating to the player
/**/


class database_connection
{
    
};

/*
the class to connect the database to the game, will also call data from the database
/**/


class enemies
{
    
};

/*
the class to hold functions relating to enemies, holds some data relating to the enemies
/**/

class health
{
  int checkHealth()
  {
      return current_Health
  }
};

/*
Deals with health calculations
/**/

class 







