class pickup
{
    public:
        int AddHealth;  //Adds value to Health
        int TurnIt;     //Modifies TurnIt Value
    
   
        
}